#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = 'api'
